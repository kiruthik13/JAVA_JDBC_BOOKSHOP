/**
 * 
 */
/**
 * 
 */
module ex5java {
	requires java.sql;
	requires mysql.connector.j;
}